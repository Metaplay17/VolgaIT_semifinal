# VolgaIT_semifinal
1. pip install -r requirements.txt
2. python run.py
## URL: http://127.0.0.1:5000/apidocs
# Небольшие примечания:
1. Не забудьте ввести username и password от базы данных в файле run.py
2. Таблица с токенами пересоздаётся при запуске сервера!